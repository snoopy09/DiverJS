# Phantom-simplecrawler

Extremely basic example which demonstrates how one might connect phantomjs to
simplecrawler to aid in link discovery.

This example utilises both phantom and simplecrawler's inbuilt discovery
function.